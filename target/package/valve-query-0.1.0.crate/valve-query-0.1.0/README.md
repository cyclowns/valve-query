# valve-query
Rust API allowing for querying information from Valve Source/Goldsrc game servers (TF2, CS:S, etc.) (!!!WIP!!!)
